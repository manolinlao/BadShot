import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { DetailsSheet } from '../components/CreateShot/DetailsSheet';
import { PhotoPicker } from '../components/CreateShot/PhotoPicker';
import { RatingQuick } from '../components/CreateShot/RatingQuick';
import type { RoastLevel } from '../domain/coffee/roastLevel';
import { useLocalShots } from '../hooks/useLocalShots';
import type { Shot } from '../types/shot';

export function CreateShot() {
  const navigate = useNavigate();
  const { shotId } = useParams();
  const { addShot, createdShots, updateShot } = useLocalShots();
  const editingShot = useMemo(
    () => createdShots.find((shot) => shot.id === shotId),
    [createdShots, shotId]
  );
  const editing = Boolean(shotId);

  const [sheetOpen, setSheetOpen] = useState(false);
  const [editLoaded, setEditLoaded] = useState(false);

  const [imageUrl, setImageUrl] = useState('');
  const [rating, setRating] = useState(3);
  const [location, setLocation] = useState('');

  const [coffeeName, setCoffeeName] = useState('');
  const [origin, setOrigin] = useState('');
  const [roaster, setRoaster] = useState('');
  const [roastLevel, setRoastLevel] = useState<RoastLevel | ''>('');
  const [doseIn, setDoseIn] = useState<number | ''>('');
  const [doseOut, setDoseOut] = useState<number | ''>('');
  const [time, setTime] = useState<number | ''>('');
  const [notes, setNotes] = useState('');
  const canSave = Boolean(imageUrl);

  useEffect(() => {
    if (!editingShot || editLoaded) return;

    setImageUrl(editingShot.imageUrl ?? '');
    setRating(editingShot.rating ?? 3);
    setLocation(editingShot.location?.name ?? '');
    setCoffeeName(editingShot.coffee.name ?? '');
    setOrigin(editingShot.coffee.origin ?? '');
    setRoaster(editingShot.coffee.roaster ?? '');
    setRoastLevel(editingShot.coffee.roastLevel ?? '');
    setDoseIn(editingShot.recipe?.doseIn ?? '');
    setDoseOut(editingShot.recipe?.doseOut ?? '');
    setTime(editingShot.recipe?.time ?? '');
    setNotes(editingShot.tastingNotes ?? '');
    setEditLoaded(true);
  }, [editLoaded, editingShot]);

  const handleSave = () => {
    if (!canSave) return;

    const shot: Shot = {
      id: editingShot?.id ?? `shot-${Date.now()}`,
      user: editingShot?.user ?? { displayName: 'You', username: 'local' },

      imageUrl,
      rating,

      location: location ? { name: location } : { name: 'Home' },

      coffee: {
        name: coffeeName,
        origin,
        roaster,
        roastLevel: roastLevel || undefined
      },

      recipe: {
        doseIn: doseIn ? Number(doseIn) : undefined,
        doseOut: doseOut ? Number(doseOut) : undefined,
        time: time ? Number(time) : undefined
      },

      tastingNotes: notes,

      likesCount: editingShot?.likesCount ?? 0,
      commentsCount: editingShot?.commentsCount ?? 0,
      brewedAt: editingShot?.brewedAt ?? new Date().toISOString(),
      createdAt: editingShot?.createdAt ?? new Date().toISOString()
    };

    if (editingShot) {
      updateShot(shot);
      navigate('/', { state: { flash: 'Shot updated' } });
      return;
    }

    addShot(shot);
    navigate('/', { state: { flash: 'Shot saved' } });
  };

  return (
    <div className='max-w-md mx-auto space-y-5'>
      <h1 className='text-xl font-bold text-center'>{editing ? 'Edit shot' : 'New shot'}</h1>

      <PhotoPicker imageUrl={imageUrl} onImageSelected={setImageUrl} />

      <input
        placeholder='Location'
        value={location}
        onChange={(e) => setLocation(e.target.value)}
        className='w-full border rounded-xl px-3 py-2'
      />

      <RatingQuick value={rating} onChange={setRating} />

      <DetailsSheet
        open={sheetOpen}
        onOpen={() => setSheetOpen(true)}
        onClose={() => setSheetOpen(false)}
        coffeeName={coffeeName}
        setCoffeeName={setCoffeeName}
        origin={origin}
        setOrigin={setOrigin}
        roaster={roaster}
        setRoaster={setRoaster}
        roastLevel={roastLevel}
        setRoastLevel={setRoastLevel}
        doseIn={doseIn}
        setDoseIn={setDoseIn}
        doseOut={doseOut}
        setDoseOut={setDoseOut}
        time={time}
        setTime={setTime}
        notes={notes}
        setNotes={setNotes}
      />

      <button
        onClick={handleSave}
        disabled={!canSave}
        className='w-full rounded-xl bg-black py-3 text-white transition hover:bg-zinc-800 disabled:cursor-not-allowed disabled:bg-zinc-300 disabled:text-zinc-500 disabled:hover:bg-zinc-300'
      >
        {editing ? 'Update shot' : 'Save shot'}
      </button>
    </div>
  );
}
